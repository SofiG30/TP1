package tp1.logic;

import tp1.view.Messages;
import tp1.logic.gameobjects.Lemming;
import tp1.logic.gameobjects.Wall;
import tp1.logic.gameobjects.ExitDoor;

public class Game implements GameModel, GameStatus, GameWorld {
	
	//calls to the game result from call by the game via the container -> part of an update
	public static final int DIM_X = 10;
	public static final int DIM_Y = 10;
	
	private GameObjectContainer container;
	private int cycle;
	private int lemmingsWin;
	private int level;
	
	// Constructor
	public Game(int nLevel) {
		this.level = nLevel;
		reset();
		
	}
	
	public GameObjectContainer getContainer() {
		return container;		
	}
	
	
	// Methods declared in GameModel
	public boolean isFinished() {
		if (playerLooses() || playerWins()) {
			return true;
		}
		return false;
	}
	
	
	public void reset() {
		this.cycle = 0;
		if (level == 0) {
			initGame0();
		} else if (level == 2){
			initGame2();
		} else if (level == 3) {
			initGame3();
		} else {
			initGame1();
		} 
	}
	
	
	// update method
		public void update() {
			cycle++;
			container.update();
		}
		
		
	// Methods declared in GameWorld
	public boolean isInAir(Position pos) {
		return container.InAir(pos);
	}
		
	public boolean lemmingArrived(Position pos) {
		return container.lemmingArrived(pos);		
	}
	
	
	// Methods declared in GameStatus
	public int getCycle() {
		return cycle;
	}
	
	// methods for stats displayed
	public int numLemmingsInBoard() {
		return container.getNbLemmings() - (numLemmingsDead() + numLemmingsExit());
	}
		
	public String positionToString(int col, int row) {
		return container.drawBoard(col, row);
	} 
	
	public int numLemmingsDead() {
		return container.nbDeadLemmings();
	}
	

	public int numLemmingsExit() { 
		return container.nbExitLemmings();
	}

	public int numLemmingsToWin() {
		return lemmingsWin;
	} 
	
	public String help() {
		return String.join("\n", Messages.HELP_LINES);
	}
	
	public String exit() {
		if (playerWins()) {
			return Messages.PLAYER_WINS;
		} 
		return Messages.PLAYER_LOOSES;
	}
	
	public int getLevel() {
		return level;
	}
	// methods that initialise the world	
	public void  initGame0() {
		this.container = new GameObjectContainer();
		// method that will initialise all the objects of the game
		container.add(new Lemming(this,new Position(9,0),Direction.RIGHT));
		container.add(new Lemming(this,new Position(2,3),Direction.RIGHT));
		container.add(new Lemming(this,new Position(0,8),Direction.RIGHT));
		container.add(new Wall(this,new Position(8,1)));
		container.add(new Wall(this,new Position(9,1)));
		container.add(new Wall(this, new Position(2,4)));
		container.add(new Wall(this,new Position(3,4)));
		container.add(new Wall(this,new Position(4,4)));
		container.add(new Wall(this, new Position(7,5)));
		container.add(new Wall(this, new Position(7,6)));
		container.add(new Wall(this, new Position(6,6)));
		container.add(new Wall(this, new Position(5,6)));
		container.add(new Wall(this, new Position(4,6)));
		container.add(new Wall(this, new Position(8,8)));
		container.add(new Wall(this, new Position(9,9)));
		container.add(new Wall(this, new Position(8,9)));
		container.add(new Wall(this, new Position(1,9)));
		container.add(new Wall(this, new Position(0,9)));
		container.add(new ExitDoor(this, new Position(4,5)));
		this.lemmingsWin = 2;
		
	}
	
	public void initGame1() {
		this.container = new GameObjectContainer();
		container.add(new Lemming(this,new Position(9,0),Direction.RIGHT));
		container.add(new Lemming(this,new Position(2,3),Direction.RIGHT));
		container.add(new Lemming(this,new Position(3,3),Direction.RIGHT));
		container.add(new Lemming(this,new Position(0,8),Direction.RIGHT));
		container.add(new Wall(this,new Position(8,1)));
		container.add(new Wall(this, new Position(9,1)));
		container.add(new Wall(this,new Position(2,4)));
		container.add(new Wall(this, new Position(3,4)));
		container.add(new Wall(this, new Position(4,4)));
		container.add(new Wall(this, new Position(7,5)));
		container.add(new Wall(this, new Position(7,6)));
		container.add(new Wall(this, new Position(6,6)));
		container.add(new Wall(this, new Position(5,6)));
		container.add(new Wall(this, new Position(4,6)));
		container.add(new Wall(this, new Position(8,8)));
		container.add(new Wall(this, new Position(9,9)));
		container.add(new Wall(this, new Position(8,9)));
		container.add(new Wall(this, new Position(1,9)));
		container.add(new Wall(this, new Position(0,9)));
		container.add(new ExitDoor(this, new Position(4,5))); // Error is the door
		this.lemmingsWin = 2;
	}
	
	// World where the player wins
	public void initGame2() {
		this.container = new GameObjectContainer();  
	    container.add(new Lemming(this, new Position(7, 0), Direction.LEFT));
	    container.add(new Lemming(this, new Position(6, 2), Direction.LEFT));
	    container.add(new Lemming(this, new Position(1, 6), Direction.RIGHT));
	    container.add(new Lemming(this, new Position(7, 2), Direction.RIGHT));
	    container.add(new Lemming(this, new Position(1, 6), Direction.RIGHT));
	    container.add(new Wall(this,new Position(7, 1)));  
	    container.add(new Wall(this, new Position(8, 1)));  
	    container.add(new Wall(this, new Position(0, 3)));
	    container.add(new Wall(this, new Position(1, 3)));
	    container.add(new Wall(this, new Position(6, 3)));
	    container.add(new Wall(this, new Position(7, 4)));
	    container.add(new Wall(this, new Position(4, 5)));
	    container.add(new Wall(this, new Position(5, 5)));
	    container.add(new Wall(this, new Position(6, 5)));
	    container.add(new Wall(this, new Position(0, 7)));
	    container.add(new Wall(this, new Position(1, 7)));
	    container.add(new Wall(this, new Position(6, 8)));
	    container.add(new Wall(this, new Position(2, 8)));
	    container.add(new Wall(this, new Position(3, 8)));
	    container.add(new Wall(this, new Position(4, 8)));
	    container.add(new Wall(this, new Position(5, 8)));
	    container.add(new Wall(this, new Position(3, 6)));
	    container.add(new ExitDoor(this, new Position(5, 7)));
	    this.lemmingsWin = 3;
	}
	 
	// world where a lemming gets stucked ( Never ends)
	public void initGame3() {
		this.container = new GameObjectContainer();
	    container.add(new Lemming(this, new Position(2, 2), Direction.LEFT));   
	    container.add(new Lemming(this, new Position(4, 2), Direction.RIGHT));  
	    container.add(new Lemming(this, new Position(6, 1), Direction.RIGHT));   
	    container.add(new Lemming(this, new Position(0, 7), Direction.RIGHT));
	    container.add(new Wall(this, new Position(1, 2)));  
	    container.add(new Wall(this, new Position(2, 3)));  
	    container.add(new Wall(this, new Position(6, 2)));  
	    container.add(new Wall(this, new Position(4, 4))); 
	    container.add(new Wall(this, new Position(5, 4)));  
	    container.add(new Wall(this, new Position(7, 8))); 
	    container.add(new Wall(this, new Position(3, 3))); 
	    container.add(new Wall(this, new Position(0, 8))); 
	    container.add(new Wall(this, new Position(5, 3)));
	    container.add(new Wall(this, new Position(1, 8)));
	    container.add(new Wall(this, new Position(2, 8)));
	    container.add(new Wall(this, new Position(3, 8)));
	    container.add(new Wall(this, new Position(3, 6)));
	    container.add(new Wall(this, new Position(4, 7)));
	    container.add(new ExitDoor(this, new Position(1, 7)));  
	    this.lemmingsWin = 3;
	} 

	public boolean playerWins() {
		return numLemmingsInBoard() == 0 &&
			numLemmingsExit() >= numLemmingsToWin();	
	}

	public boolean playerLooses() {
		return numLemmingsInBoard() == 0 && 
			numLemmingsExit() < numLemmingsToWin();
	}

	
}
