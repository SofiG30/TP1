package tp1.logic;

public interface GameModel {
	// Represents the controllers view
	boolean isFinished();
	void update();
	void reset();
	String help();
	String exit();
	
	// TODO add methods that implement the commands entered by the user
	// and those that return information about the state of the game
}
