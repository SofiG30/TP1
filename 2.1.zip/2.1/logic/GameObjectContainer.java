package tp1.logic;
import java.util.ArrayList;
import java.util.List;

import tp1.logic.gameobjects.ExitDoor;
import tp1.logic.gameobjects.GameObject;
import tp1.logic.gameobjects.Lemming;
import tp1.logic.gameobjects.Wall;

public class GameObjectContainer {
	//TODO fill your code
	private List<GameObject> gameObjects;
	private int deadLemmings = 0;
	private int exitedLemmings = 0;
	private int nbLemmings = 0;
	
	// Constructor 
	public GameObjectContainer() { 
		gameObjects = new ArrayList<>();
	}
	
	public int getNbLemmings() {
		return nbLemmings;
	}
	
	// method that takes a game object and adds it to the list
	public void add(GameObject object) {
		gameObjects.add(object);
		if (!object.isInanimate() && object.isAlive()) {
			nbLemmings ++;
		}
	}
	
	// methods for the display of objects
	public String drawBoard(int col, int row) {
		for (GameObject object : gameObjects) {
			Position posObject = object.getPosition();
			if (posObject.get_col() == col && posObject.get_row() == row) {
				return object.toString();
			}
		}
		return "";
	}
	
	
	public boolean Solid(int col, int row) {
		for (GameObject object : gameObjects) {
			if (object.isSolid() && object.isInanimate()) { 
				Position posObject = object.getPosition();
				if (posObject.get_col() == col && posObject.get_row() == row) {
					return true;
				}
			}
		}
		return false;
	}
	
	
	public boolean InAir(Position pos) {
		return !Solid(pos.get_col(), pos.get_row() +1);
	}
	
	
	
	public int nbDeadLemmings() {
		deadLemmings = 0;
		for (GameObject object : gameObjects) {
			if (!object.isInanimate() && !object.isAlive()) {
					deadLemmings++;								
			}
		}
		return deadLemmings;
	}
	
	
	public boolean lemmingArrived(Position pos) {
		if (isDoorPos(pos.get_col(), pos.get_row())) {
			return true;
		}
		return false;
	}
	
	
	public int nbExitLemmings() {
		exitedLemmings = 0;
		for (GameObject object : gameObjects) {
			if (object.hasExited())			
					exitedLemmings++;
		}
		return exitedLemmings;
	}
	
	
	public boolean isDoorPos(int col, int row) {
		for (GameObject object : gameObjects) {
			Position pos = object.getPosition();
			if (!object.isSolid() && object.isInanimate() &&
				pos.get_col() == col && pos.get_row() == row) {
				return true;
			}	
		}
		return false;
	}
	
	public void update() {
		for (GameObject object : gameObjects) {
			object.update();
		}
	}
}
	
	