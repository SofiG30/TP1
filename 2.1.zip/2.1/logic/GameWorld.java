package tp1.logic;

public interface GameWorld {
	// Represents the model's view
	
	boolean isInAir(Position pos);
	boolean lemmingArrived(Position pos);
	
	// TODO invoke methods of the game that concern interactions between game objects
	

}
