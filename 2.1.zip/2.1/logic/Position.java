package tp1.logic;

/**
 * 
 * Immutable class to encapsulate and manipulate positions in the game board
 * 
 */
public class Position {
 // Make them final -> return pos objects without breaking encapsulation
	private final int col;
	private final int row;

	public Position(int col, int row) {
		this.col = col;
		this.row = row;
	}
	
	// Getter methods
	public int get_col() {
		return col;
	}
	public int get_row() {
		return row;
	}

}
