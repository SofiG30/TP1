package tp1.logic.gameobjects;

import tp1.logic.Game;
import tp1.logic.Position;
import tp1.view.Messages;
public class ExitDoor extends GameObject {
	
	private Position positionDoor;
	private Game game;

	public ExitDoor(Game game, Position pos) {
		super(game, pos,false,true,false);
		this.positionDoor = pos;
		// TODO Auto-generated constructor stub
	}

		
	public Position getPosition() {
		return super.getPosition();
	}
	
	@Override
	public String toString() {
		return Messages.EXIT_DOOR;
	}
	
	public void update() {}
}


