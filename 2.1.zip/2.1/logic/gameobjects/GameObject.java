package tp1.logic.gameobjects;

import tp1.logic.Game;
import tp1.logic.Position;
//Attributes and non-abstract methods should be placed in the highest class possible
public abstract class GameObject {
	// Contains all the attributes and methods that are common to all the concrete game objects
	// Where appropriate -> Concrete game objects can overwrite inherited methods to implement its own behavior

	private Game game;
	private Position pos;
	private boolean Exited = false;
	private boolean solid;
	private boolean inanimate;
	private boolean alive;
	
	// Constructor 
	public GameObject(Game game, Position pos, boolean solid, boolean inanimate, boolean alive) {
		this.game = game;
		this.inanimate =  inanimate;
		this.pos = pos;
		this.solid = solid;
		this.alive = alive;
	}
	
	public Position getPosition() {
		return pos;
	}
	
	public boolean isInanimate() {
		return inanimate;
	}
	
	public boolean hasExited() {
		return Exited;
	}
	
	public boolean isSolid() {
		return solid;
	}
	
	public boolean isAlive() {
		return alive;
	}
	
	public void setPosition(Position pos) {
		this.pos = pos;
	}
	
	public void setAlive(boolean alive) {
		this.alive = alive;
	}
	
	public abstract String toString();
		
	public void update() {
		
	}

}



























