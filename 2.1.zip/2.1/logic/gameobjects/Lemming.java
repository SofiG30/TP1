package tp1.logic.gameobjects;
import tp1.logic.Direction;
import tp1.logic.Position;
import tp1.logic.lemmingRoles.WalkerRole;
import tp1.view.Messages;
import tp1.logic.Game;

public class Lemming extends GameObject{
	private int forceFall;
	private Game game;
	private WalkerRole role;
	private Direction direction;
	private boolean hasExited;
	private boolean isAlive;
	
	
	// Constructor for an object of class lemming
	public Lemming(Game game, Position pos, Direction direction) {
		super(game, pos,false,false,true);
		this.isAlive = true;
		this.game = game;
		this.forceFall = 0; // Init value
		this.role = new WalkerRole(); // Define after on the WalkerRole class
		this.direction = direction;  
		this.hasExited = false;
	}
	
	// getters
	public Position getPosition() {
		return super.getPosition();
	}
	
	public boolean Alive() {
		return isAlive;
	}
	
	public int getForceFall() {
		return forceFall;
	}
	
	public WalkerRole getRole() {
		return role;
	}
	
	
	public Direction getDirection() {
		return direction;
	}
	
	@Override
	public boolean hasExited() {
		return hasExited;
	}
	
	
	public void setExited(boolean Exited) {
		this.hasExited = Exited;
	}
	
	@Override
	public String toString() {
		return role.getIcon(this);
	}
	
	
	// move method / dk
	public void walkFall() {
		Position currentPos = getPosition();
		int x = currentPos.get_col();
		int y = currentPos.get_row();
		
		// Check if the lemming has reached the exit door
		if (direction == Direction.LEFT) {
			Position p = new Position(x-1,y);
			if (game.lemmingArrived(p)) {
				setExited(true);
				return;
			}
		} else if (direction == Direction.RIGHT) {
			Position p = new Position(x+1,y);
			if (game.lemmingArrived(p)) {
				setExited(true);
				return;
			}
		} 
	
		
		// If the lemming exits the game from the bottom of the board
		if (y+1 >= Game.DIM_Y) {
			setAlive(false);
			return;
		}
		
		if (hasExited) {
			return;
		}
		
		// Check if there's no wall below the lemming
		if (game.getContainer().InAir(currentPos)) {
			// The lemming will fall
			forceFall++;
			setPosition(new Position(x,y+1));	
			return;
		} else {
			// The lemming hit the ground
			if (forceFall >= 3) {
				setAlive(false);
				return;
			} else {
				forceFall = 0;
			}
		}
		
		// Horizontal movement
		
		if (direction == Direction.LEFT) {
			if ( x != 0 && !game.getContainer().Solid(x-1, y)) {
				setPosition(new Position(x-1,y));
			} else {
				direction = Direction.RIGHT;
			}
		} else if (direction == Direction.RIGHT) {
			if ( x != (Game.DIM_X -1) && !game.getContainer().Solid(x+1, y)) {
				setPosition(new Position(x+1, y));
			} else {
				direction = Direction.LEFT;
			}
		}
	}

	
	public void update() {
		// Check first that the lemming is alive 
		if (!Alive() || hasExited) return;
		// Call the advance of the WalkerRole
		role.advance(this);
		}
	}

