package tp1.logic.gameobjects;
import tp1.logic.Game;
import tp1.logic.Position;
import tp1.view.Messages;

public class Wall extends GameObject{
	
	private Position positionWall;
	private Game game;
	
	// Constructor
	public Wall(Game game, Position pos) {
		super(game, pos,true,true,false);
		this.positionWall = pos;
		// TODO Auto-generated constructor stub
	}

	
	// Getter method
	public Position getPosition() {
		return super.getPosition();
	}
	

	@Override
	public String toString() {
		return Messages.WALL;
	}
		
	public void update() {}
}
