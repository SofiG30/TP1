package tp1.logic.lemmingRoles;
import tp1.logic.Direction;
import tp1.logic.gameobjects.Lemming;
import tp1.view.Messages;
public class WalkerRole {
	
	public void advance(Lemming lemmy) {
		lemmy.walkFall();
	}
	 
	public String getIcon(Lemming lemmy) {
		
		if (!lemmy.isAlive() || lemmy.hasExited()) {
			return "";
		}
		
		if (lemmy.getDirection() == Direction.RIGHT) {
			return Messages.LEMMING_RIGHT;
		} else  {// direction left 
			return Messages.LEMMING_LEFT;
		}
		
	}
}
