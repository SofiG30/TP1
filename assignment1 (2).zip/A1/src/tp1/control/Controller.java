package tp1.control;

import tp1.logic.Game;
import tp1.view.GameView;
import tp1.view.Messages;

/**
 *  Accepts user input and coordinates the game execution logic
 */
public class Controller {

	private Game game;
	private GameView view;
	private boolean exit = true;
	public Controller(Game game, GameView view) {
		this.game = game;
		this.view = view;
	}

	/**
	 * Runs the game logic, coordinate Model(game) and View(view)
	 * 
	 */
	public void run() {
		view.showWelcome();		
		view.showGame();
		//TODO fill your code: The main loop that displays the game, asks the user for input, and executes the action.
		while (exit) {
			
			
			String[] input = view.getPrompt(); // ret string
			String command = input.length > 0 ? input[0].toLowerCase() : "none";
			
			// Check that there is actually any input
			if (command.trim().isEmpty()) {
				command = "none";
			}
			
			// Input with incorrect parameters
			if (input.length > 1) {
				System.out.println(String.format(Messages.ERROR , Messages.COMMAND_INCORRECT_PARAMETER_NUMBER));
				continue;
			}
			
			// handle the diff cases of the command
			switch (command) {
				case "h":
				case "help":				
					System.out.println(game.help());
					break;
				case "r":
				case "reset":
					System.out.println("Game Reset!");
					// Return the board to its initial state
					game.reset();
					view.showGame();
					break;
				case "e":
				case "exit":
					System.out.println(Messages.PLAYER_QUITS);
					if (game.playerWins()) {
						System.out.println(Messages.PLAYER_WINS);
					} else {
						System.out.println(Messages.PLAYER_LOOSES);
					}
					exit = false;
					break;
				case "n":
				case "none":
					game.update();
					view.showGame();
					break;	
				default:
					// Error
					System.out.println(String.format(Messages.ERROR , Messages.INVALID_COMMAND));
					break;
				
			}
			if (game.playerLooses() || game.playerWins()) {
				break;
			}
		}
		view.showEndMessage();
	}
}
