package tp1.logic;

import tp1.view.Messages;
import tp1.logic.gameobjects.Lemming;
import tp1.logic.gameobjects.Wall;
import tp1.logic.gameobjects.ExitDoor;

public class Game {

	public static final int DIM_X = 10;
	public static final int DIM_Y = 10;
	
	private GameObjectContainer container;
	private int cycle;
	private int lemmingsWin;
	private int level;
	
	// Constructor
	public Game(int nLevel) {
		this.level = nLevel;
		reset();
		
	}
	
	// reset method
	public void reset() {
		this.cycle = 0;
		if (level == 0) {
			initGame0();
		} else if (level == 2){
			initGame2();
		} else if (level == 3) {
			initGame3();
		} else {
			initGame1();
		}
	}
	
	// methods that initialise the world	
	public void  initGame0() {
		this.container = new GameObjectContainer(3,15);
		// method that will initialise all the objects of the game
		container.add(new Lemming(this,new Position(9,0),Direction.RIGHT));
		container.add(new Lemming(this,new Position(2,3),Direction.RIGHT));
		container.add(new Lemming(this,new Position(0,8),Direction.RIGHT));
		container.add(new Wall(new Position(8,1)));
		container.add(new Wall(new Position(9,1)));
		container.add(new Wall(new Position(2,4)));
		container.add(new Wall(new Position(3,4)));
		container.add(new Wall(new Position(4,4)));
		container.add(new Wall(new Position(7,5)));
		container.add(new Wall(new Position(7,6)));
		container.add(new Wall(new Position(6,6)));
		container.add(new Wall(new Position(5,6)));
		container.add(new Wall(new Position(4,6)));
		container.add(new Wall(new Position(8,8)));
		container.add(new Wall(new Position(9,9)));
		container.add(new Wall(new Position(8,9)));
		container.add(new Wall(new Position(1,9)));
		container.add(new Wall(new Position(0,9)));
		container.add(new ExitDoor(new Position(4,5)));
		this.lemmingsWin = 2;
		
	}
	
	public void initGame1() {
		this.container = new GameObjectContainer(4,15);
		container.add(new Lemming(this,new Position(9,0),Direction.RIGHT));
		container.add(new Lemming(this,new Position(2,3),Direction.RIGHT));
		container.add(new Lemming(this,new Position(3,3),Direction.RIGHT));
		container.add(new Lemming(this,new Position(0,8),Direction.RIGHT));
		container.add(new Wall(new Position(8,1)));
		container.add(new Wall(new Position(9,1)));
		container.add(new Wall(new Position(2,4)));
		container.add(new Wall(new Position(3,4)));
		container.add(new Wall(new Position(4,4)));
		container.add(new Wall(new Position(7,5)));
		container.add(new Wall(new Position(7,6)));
		container.add(new Wall(new Position(6,6)));
		container.add(new Wall(new Position(5,6)));
		container.add(new Wall(new Position(4,6)));
		container.add(new Wall(new Position(8,8)));
		container.add(new Wall(new Position(9,9)));
		container.add(new Wall(new Position(8,9)));
		container.add(new Wall(new Position(1,9)));
		container.add(new Wall(new Position(0,9)));
		container.add(new ExitDoor(new Position(4,5)));
		this.lemmingsWin = 2;
	}
	
	// World where the player wins
	public void initGame2() {
		this.container = new GameObjectContainer(5, 17);  
	    container.add(new Lemming(this, new Position(7, 0), Direction.LEFT));
	    container.add(new Lemming(this, new Position(6, 2), Direction.LEFT));
	    container.add(new Lemming(this, new Position(1, 6), Direction.RIGHT));
	    container.add(new Lemming(this, new Position(7, 2), Direction.RIGHT));
	    container.add(new Lemming(this, new Position(1, 6), Direction.RIGHT));
	    container.add(new Wall(new Position(7, 1)));  
	    container.add(new Wall(new Position(8, 1)));  
	    container.add(new Wall(new Position(0, 3)));
	    container.add(new Wall(new Position(1, 3)));
	    container.add(new Wall(new Position(6, 3)));
	    container.add(new Wall(new Position(7, 4)));
	    container.add(new Wall(new Position(4, 5)));
	    container.add(new Wall(new Position(5, 5)));
	    container.add(new Wall(new Position(6, 5)));
	    container.add(new Wall(new Position(0, 7)));
	    container.add(new Wall(new Position(1, 7)));
	    container.add(new Wall(new Position(6, 8)));
	    container.add(new Wall(new Position(2, 8)));
	    container.add(new Wall(new Position(3, 8)));
	    container.add(new Wall(new Position(4, 8)));
	    container.add(new Wall(new Position(5, 8)));
	    container.add(new Wall(new Position(3, 6)));
	    container.add(new ExitDoor(new Position(5, 7)));
	    this.lemmingsWin = 3;
	}
	 
	// world where a lemming gets stucked ( Never ends)
	public void initGame3() {
		this.container = new GameObjectContainer(4, 14);
	    container.add(new Lemming(this, new Position(2, 2), Direction.LEFT));   
	    container.add(new Lemming(this, new Position(4, 2), Direction.RIGHT));  
	    container.add(new Lemming(this, new Position(6, 1), Direction.RIGHT));   
	    container.add(new Lemming(this, new Position(0, 7), Direction.RIGHT));
	    container.add(new Wall(new Position(1, 2)));  
	    container.add(new Wall(new Position(2, 3)));  
	    container.add(new Wall(new Position(6, 2)));  
	    container.add(new Wall(new Position(4, 4))); 
	    container.add(new Wall(new Position(5, 4)));  
	    container.add(new Wall(new Position(7, 8))); 
	    container.add(new Wall(new Position(3, 3))); 
	    container.add(new Wall(new Position(0, 8))); 
	    container.add(new Wall(new Position(5, 3)));
	    container.add(new Wall(new Position(1, 8)));
	    container.add(new Wall(new Position(2, 8)));
	    container.add(new Wall(new Position(3, 8)));
	    container.add(new Wall(new Position(3, 6)));
	    container.add(new Wall(new Position(4, 7)));
	    container.add(new ExitDoor(new Position(1, 7)));  
	    this.lemmingsWin = 3;
	}
	
	// getters
	public int getLevel() {
		return level;
	}
	public GameObjectContainer getContainer() {
		return container;		
	}
	public int getCycle() {
		return cycle;
	}
	
	// methods for stats displayed
	public int numLemmingsInBoard() {
		return container.get_nb_lemmings() - (numLemmingsDead() + numLemmingsExit());
	}

	public int numLemmingsDead() {
		return container.nb_deadLemmings();
	}
	

	public int numLemmingsExit() { 
		return container.nb_exitLemmings();
	}

	public int numLemmingsToWin() {
		return lemmingsWin;
	}

	public String positionToString(int col, int row) {
		
		// Check door pos and display it
		if (container.isDoor_pos(col, row)) {
			return container.get_exit_door();
		}
		
		String lemmy_icon = container.draw_lemming(col, row);
		if (!lemmy_icon.equals("")) {
			return lemmy_icon;
		}
		
		String wall_icon = container.draw_walls(col, row);
		if (!wall_icon.equals("")) {
			return wall_icon;
		}
		return " ";
	}

	public boolean playerWins() {
		return numLemmingsInBoard() == 0 &&
			numLemmingsExit() >= numLemmingsToWin();	
	}

	public boolean playerLooses() {
		return numLemmingsInBoard() == 0 && 
			numLemmingsExit() < numLemmingsToWin();
	}

	public String help() {
		return String.join("\n", Messages.HELP_LINES);
	}
	
	// update method
	public void update() {
		cycle++;
		container.update();
	}
}
