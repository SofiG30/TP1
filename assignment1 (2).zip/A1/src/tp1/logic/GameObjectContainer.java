package tp1.logic;
import tp1.logic.gameobjects.ExitDoor;
import tp1.logic.gameobjects.Lemming;
import tp1.logic.gameobjects.Wall;

public class GameObjectContainer {
	//TODO fill your code
	private ExitDoor exit_door;
	private Lemming[] lemmings;
	private int nb_lemmings;
	private Wall[] walls;
	private int nb_walls;
	
	// Constructor 
	public GameObjectContainer(int max_lemmings, int max_walls) { 
		this.nb_lemmings = 0;
		this.nb_walls = 0;
		lemmings = new Lemming[max_lemmings];
		walls = new Wall[max_walls];
	}
	
	// Getters
	public int get_nb_lemmings() {
		return nb_lemmings;
	}
	
	public int get_nb_walls() {
		return nb_walls;
	}
	
	public String get_exit_door() {
		return exit_door.toString();
	}
	
	public ExitDoor getExitDoor() {
		return exit_door;
	}
	
	public Lemming getLemming(int index) {
		if (index >= 0 && index < nb_lemmings) {
			return lemmings[index];
		}
		return null;
	}
	
	public Wall getWall(int index) {
		if (index >= 0 && index < nb_walls) {
			return walls[index];
		}
		return null;
	}
	
	// methods for the display of objects
	public boolean isDoor_pos(int col, int row) {
		Position door_pos = exit_door.get_pos_Door();
		return door_pos.get_col() == col && door_pos.get_row() == row;
	}
	

	
	public String draw_lemming(int col, int row) {
		for (int i = 0; i < nb_lemmings; i ++) {
			Lemming lemmy = lemmings[i];
			Position lemmy_pos = lemmy.get_position();
			if (lemmy_pos.get_col() == col && lemmy_pos.get_row() == row && lemmy.state()) {
				return lemmy.getLemming_Icon(); // doesnt work
			}
		}
		return "";
	}
	
	public String draw_walls(int col, int row) {
		for (int i = 0; i < nb_walls; i++) {
			Wall wall = walls[i];
			Position wall_pos = wall.get_position_Wall();
			if (wall_pos.get_col() == col && wall_pos.get_row() == row) {
				return wall.toString();
			}
		}
		return "";
		
	}
	
	// methods to add an object to its attribute
	public void add(Lemming lemming) {
		if (nb_lemmings < lemmings.length) {
			lemmings[nb_lemmings] = lemming;
			nb_lemmings++;
		}
	}
	
	public void add(Wall wall) {
		if (nb_walls < walls.length) {
			walls[nb_walls] = wall;
			nb_walls++;
		}
	}
	
	public void add(ExitDoor exitDoor) {
		this.exit_door = exitDoor;
		
	}
	
	// Method that handles the solid / not solid conditions of the objects
	public boolean Solid(int col, int row) {
		for (int i = 0; i < nb_walls; i++) {
			Position pos = walls[i].get_position_Wall();
			if (pos.get_col() == col && pos.get_row() == row) {
				return true;
			}
		}
		return false;
	}
	
	// Methods that checks the number of dead lemmings
	public int nb_deadLemmings() {
		int count = 0;
		for (int i = 0; i < nb_lemmings; i++) {
			if(!lemmings[i].state()) {
				count++;
			}
		}
		return count;
	}
	
	// chec if a lemming has exited the game from the door
	public int nb_exitLemmings() {
		int count = 0;
		for (int i = 0; i < nb_lemmings; i++) {
			Lemming lemmy = lemmings[i];
			if (lemmy.hasExited()) {
				count++;
			}
		}
		return count;
	}
	
	// update method
	public void update() {
		for (int i = 0; i < nb_lemmings; i++) {
			Lemming lemmy = lemmings[i];
			if (!lemmy.hasExited() && lemmy.state()) {
				lemmings[i].update();
			}
		}
		for (int i = 0; i < nb_walls; i++) {
			walls[i].update();
		}
		exit_door.update();
	}
}
