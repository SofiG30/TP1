package tp1.logic;

/**
 * 
 * Immutable class to encapsulate and manipulate positions in the game board
 * 
 */
public class Position {

	private int col;
	private int row;

	public Position(int col, int row) {
		this.col = col;
		this.row = row;
	}
	
	// Getter methods
	public int get_col() {
		return col;
	}
	public int get_row() {
		return row;
	}

}
