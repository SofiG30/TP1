package tp1.logic.gameobjects;

import tp1.logic.Position;
import tp1.view.Messages;
public class ExitDoor {

	private Position position_door;
	
	public ExitDoor(Position position) {
		this.position_door = position;
	}
	
	public Position get_pos_Door() {
		return position_door;
	}
	
	public String toString() {
		return Messages.EXIT_DOOR;
	}
	
	public void update() {}
}
