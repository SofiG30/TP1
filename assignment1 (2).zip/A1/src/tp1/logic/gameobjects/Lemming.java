package tp1.logic.gameobjects;
import tp1.logic.Direction;
import tp1.logic.Position;
import tp1.logic.lemmingRoles.WalkerRole;
import tp1.view.Messages;
import tp1.logic.Game;

public class Lemming {
	private boolean is_alive;
	private Position pos;
	private int force_fall;
	private Game game;
	private WalkerRole role;
	private Direction direction;
	private boolean hasExited;
	
	
	// Constructor for an object of class lemming
	public Lemming(Game game, Position pos, Direction direction) {
		this.is_alive = true; // Default val is that the lemming is alive
		this.pos = pos;
		this.force_fall = 0; // Init value
		this.game = game;
		this.role = new WalkerRole(); // Define after on the WalkerRole class
		this.direction = direction;  
		this.hasExited = false;
	}
	
	// getters
	public Position get_position() {
		return pos;
	}
	
	public int get_force_fall() {
		return force_fall;
	}
	
	public WalkerRole get_role() {
		return role;
	}
	
	
	public Direction get_direction() {
		return direction;
	}
	
	public boolean state() {
		return is_alive;
	}
	
	public boolean hasExited() {
		return hasExited;
	}
	
	
	public String getLemming_Icon() {
		return role.getIcon(this);
	}
	
	// move method
	public void Walk_Fall() {
		int x = pos.get_col();
		int y = pos.get_row();
		
		// Check if the lemming has reached the exit door
		if (game.getContainer().isDoor_pos(x, y)) {
			hasExited = true;
			return;
		}
		
		// If the lemming exits the game from the bottom of the board
		if (y >= Game.DIM_Y) {
			is_alive = false;
			return;
		}
		
		if (hasExited) {
			return;
		}
		
		// Check if there's no wall below the lemming
		if (!game.getContainer().Solid(x, y+1)) {
			// The lemming will fall
			force_fall++;
			pos = new Position(x,y+1);	
			return;
		} else {
			// The lemming hit the ground
			if (force_fall >= 3) {
				is_alive = false;
				return;
			} else {
				force_fall = 0;
			}
		}
		
		// Horizontal movement
		
		if (direction == Direction.LEFT) {
			if ( x != 0 && !game.getContainer().Solid(x-1, y)) {
				pos = new Position(x-1,y);
			} else {
				direction = Direction.RIGHT;
			}
		} else if (direction == Direction.RIGHT) {
			if ( x != (Game.DIM_X -1) && !game.getContainer().Solid(x+1, y)) {
				pos = new Position(x+1, y);
			} else {
				direction = Direction.LEFT;
			}
		}
	}
		
	/**
	 *  Implements the automatic update	
	 */
	public void update() {
		// Check first that the lemming is alive 
		if (!is_alive || hasExited) return;
		// Call the advance of the WalkerRole
		role.advance(this);
		}
	}

