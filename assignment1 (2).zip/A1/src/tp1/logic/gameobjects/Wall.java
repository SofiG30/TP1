package tp1.logic.gameobjects;
import tp1.logic.Position;
import tp1.view.Messages;

public class Wall {
	
	private Position position_wall;
	
	// Constructor
	public Wall(Position position) {
		this.position_wall = position;
	}
	
	// Getter method
	public Position get_position_Wall() {
		return position_wall;
	}
	
	public String toString() {
		return Messages.WALL;
	}
	
	public void update() {}
}
