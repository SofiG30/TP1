package control;

import logic.Game;
import logic.GameModel;
import view.GameView;

public abstract class Command {
	// Encapsulates functionality of all concrete commands
	private String name;
	private String shortcut;
	private String details;
	private String help;
	
	// Constructor
	public Command(String name, String shortcut, String details, String help) {
		this.name = name;
		this.shortcut = shortcut;
		this.details = details;
		this.help = help;
	}
	
	// Getter methods
	public String getName() {
		return name;
	}
	
	public String getShortcut() {
		return shortcut;
	}
	
	public String getDetails() {
		return details;
	}
	
	public String getHelp() {
		return help;
	}

	
	public abstract Command parse(String[] command);
	
	public abstract void execute(GameModel game, GameView view);
	
	public String helpText() {
		return details + ": " + help;
	}
}
