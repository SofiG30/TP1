package control;

import java.util.Arrays;
import java.util.List;

import view.Messages;

public class CommandGenerator {
	// the list contains the instances of the class Command 
	private static final List<Command> AVAILABLE_COMMANDS = Arrays.asList
			(
			new NoneCommand(),
			new ResetCommand(),
			new HelpCommand(),
			new ExitCommand(),
			new SetRoleCommand()
		);
	
	public static Command parse(String[] commandWords) {
		// returns an instance of the concrete command classes
		// traverses the list calling the parse method of each class instance -> returns the first non-null value found
		// else null
		for (Command command : AVAILABLE_COMMANDS) {
			if  (command.parse(commandWords) != null) {
				return command;
			}
		}
		return null;
	}
	
	public static String commandHelp() {
		// output of the help Command -> must be called by the execute method of the HelpCommand class
		// traverses the list A_C -> invokes the HelpText method of each object on the list
		System.out.println(Messages.HELP_AVAILABLE_COMMANDS);
		String help = "";
		for (Command command : AVAILABLE_COMMANDS) {
			if (command.helpText() != null) {
				help += command.helpText() + "\n";
			}
		}
		return help;
	}
}
