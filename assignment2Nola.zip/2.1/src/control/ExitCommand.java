package control;

import logic.*;
//import tp1.logic.GameModel;
import view.*;

//import tp1.view.Messages;


public class ExitCommand extends NoParamsCommand {
	
	private static final String NAME = Messages.COMMAND_EXIT_NAME;
	private static final String SHORTCUT = Messages.COMMAND_EXIT_SHORTCUT;
	private static final String DETAILS = Messages.COMMAND_EXIT_DETAILS;
	private static final String HELP = Messages.COMMAND_EXIT_HELP;
	
	
	public ExitCommand() {
		super(NAME, SHORTCUT, DETAILS, HELP);
		// TODO Auto-generated constructor stub
	}

	protected boolean matchCommand(String command) {
		// Checks if the first word of the text corresponds to the command name -> parse method 
		return super.matchCommand(command);
	}
	
	public Command parse(String[]command) {
		// Checks if the text introduced by the user corresponds to a use of the command -> Check validity of the parameter values 
		return super.parse(command);
		
	}
	
	@Override
	public void execute(GameModel game, GameView view) {
		System.out.println(Messages.PLAYER_QUITS);
		game.exit();	
	}
	
	public String helpText() {
		return super.helpText();
	}

}
