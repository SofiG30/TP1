package control;

import logic.*;
//import tp1.logic.GameModel;
import view.*;
//import tp1.view.Messages;

public class HelpCommand extends NoParamsCommand {
	
	private static final String NAME = Messages.COMMAND_HELP_NAME;
	private static final String SHORTCUT = Messages.COMMAND_HELP_SHORTCUT;
	private static final String DETAILS = Messages.COMMAND_HELP_DETAILS;
	private static final String HELP = Messages.COMMAND_HELP_HELP;
	
 

	public HelpCommand() {
		super(NAME, SHORTCUT, DETAILS, HELP);
		// TODO Auto-generated constructor stub
	}
	
	// Implementation of execute 

	protected boolean matchCommand(String command) {
		// Checks if the first word of the text corresponds to the command name -> parse method 
		return super.matchCommand(command);
	}

	public Command parse(String[]command) {
		// Checks if the text introduced by the user corresponds to a use of the command -> Check validity of the parameter values 
		return super.parse(command);
		
	}
	
	@Override
	public void execute(GameModel game, GameView view) {
		String command_help = CommandGenerator.commandHelp();
		view.showMessage(command_help);
		
	}
}
