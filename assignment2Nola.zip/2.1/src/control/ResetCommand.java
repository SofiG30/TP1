package control;

import logic.*;
import logic.GameModel;
import view.*;
import view.Messages;

public class ResetCommand extends NoParamsCommand {

	private static final String NAME = Messages.COMMAND_RESET_NAME;
	private static final String SHORTCUT = Messages.COMMAND_RESET_SHORTCUT;
	private static final String DETAILS = Messages.COMMAND_RESET_DETAILS;
	private static final String HELP = Messages.COMMAND_RESET_HELP;
	
	
	public ResetCommand() {
		super(NAME, SHORTCUT, DETAILS, HELP);
		// TODO Auto-generated constructor stub
	}

	protected boolean matchCommand(String command) {
		return super.matchCommand(command);
	}
	
	public Command parse(String[]command) {
		// Checks if the text introduced by the user corresponds to a use of the command -> Check validity of the parameter values 
		return super.parse(command);
	}
	
	@Override
	public void execute(GameModel game, GameView view) {
		game.reset();
		view.showGame();		
	}

	public String helpText() {
		return super.helpText();
	}
}
