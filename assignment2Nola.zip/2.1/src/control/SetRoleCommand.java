package control;

import logic.*;
import logic.lemmingRoles.*;
import view.*;

public class SetRoleCommand extends Command {

	private static final String NAME = "setRole";
	private static final String SHORTCUT = "sr";
	private static final String DETAILS = "[s]et[R]ole ROLE ROW COL";
	private static final String HELP = "Set the role of a lemming.";
	
	private LemmingRole role;
	private Position pos;
	
	public SetRoleCommand() {
		super(NAME, SHORTCUT, DETAILS, HELP)
	}
	
	@Override
	public Command parse(String[] command) {
		//checks input format
		if(command.length == 4 && matchCommand(command[0])) {
			try {
				role = LemmingRoleFactory.parse(command[1]);
				int row = Integer.parseInt(command[2]);
				int col = Integer.parseInt(command[3]);
				pos = new Position(col-1, row-1);
				return this;
			}
			catch(Exception e) {
				//invalid role or position
				return null;
			}
		}
		return null;
	}
	
	@Override
	public void execute(GameModel game, GameView view) {
		//if wrong role or no lemmy at pos, print error message
		if(role == null || !game.setRole(role, pos)) {
			view.showError(Messages.INVALID_POSITION);
		}
	}
	
}
