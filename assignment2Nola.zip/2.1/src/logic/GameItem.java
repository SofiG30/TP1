package logic;

import logic.gameobjects.*;

public interface GameItem {

	boolean receiveInteraction(GameItem other);
	
	boolean interactWith(Lemming lemming);
	boolean interactWith(Wall wall);
	boolean interactWith(ExitDoor door);
	
	boolean isSolid();
	boolean isAlive();
	boolean isExit();
	boolean isInPosition(Position pos);
	
	default boolean canBeDug() {
		return true;
	}
	default boolean interactWith(MetalWall wall) {
		return false;
	}
}
