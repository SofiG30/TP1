package logic;
import java.util.ArrayList;
import logic.lemmingRoles.*;

import java.util.List;

import logic.gameobjects.ExitDoor;
import logic.gameobjects.GameObject;
import logic.gameobjects.Lemming;
import logic.gameobjects.Wall;

public class GameObjectContainer {
	//TODO fill your code
	private List<GameObject> gameObjects;
	private int deadLemmings = 0;
	private int exitedLemmings = 0;
	private int nbLemmings = 0;
	
	// Constructor 
	public GameObjectContainer() { 
		gameObjects = new ArrayList<>();
	}
	
	public int getNbLemmings() {
		return nbLemmings;
	}
	
	// method that takes a game object and adds it to the list
	public void add(GameObject object) {
		gameObjects.add(object);
		if (!object.isInanimate() && object.isAlive()) {
			nbLemmings ++;
		}
	}
	
	// methods for the display of objects
	public String drawBoard(int col, int row) {
		for (GameObject object : gameObjects) {
			Position posObject = object.getPosition();
			if (posObject.get_col() == col && posObject.get_row() == row) {
				return object.toString();
			}
		}
		return "";
	}
	
	
	public boolean Solid(int col, int row) {
		for (GameObject object : gameObjects) {
			if (object.isSolid() && object.isInanimate()) { 
				Position posObject = object.getPosition();
				if (posObject.get_col() == col && posObject.get_row() == row) {
					return true;
				}
			}
		}
		return false;
	}
	
	
	public boolean InAir(Position pos) {
		return !Solid(pos.get_col(), pos.get_row() +1);
	}
	
	
	
	public int nbDeadLemmings() {
		deadLemmings = 0;
		for (GameObject object : gameObjects) {
			if (!object.isInanimate() && !object.isAlive()) {
					deadLemmings++;								
			}
		}
		return deadLemmings;
	}
	
	
	public boolean lemmingArrived(Position pos) {
		if (isDoorPos(pos.get_col(), pos.get_row())) {
			return true;
		}
		return false;
	}
	
	
	public int nbExitLemmings() {
		exitedLemmings = 0;
		for (GameObject object : gameObjects) {
			if (object.hasExited())			
					exitedLemmings++;
		}
		return exitedLemmings;
	}
	
	
	public boolean isDoorPos(int col, int row) {
		for (GameObject object : gameObjects) {
			Position pos = object.getPosition();
			if (!object.isSolid() && object.isInanimate() &&
				pos.get_col() == col && pos.get_row() == row) {
				return true;
			}	
		}
		return false;
	}
	
	public void update() {
		for (GameObject object : gameObjects) {
			object.update();
		}
	}
	
	public boolean setRole(LemmingRole role, Position pos) {
		for(GameObject obj: gameObjects) {
			//role is assigned
			if(obj.isInPosition(pos) && obj.setRole(role)) {
				return true;
			}
		}
		//not assigned
		return false;
	}
	
	public boolean receiveInteractionsFrom(GameItem initiator, Position pos) {
	    for (GameObject obj : gameObjects) {
	        if (obj.isInPosition(pos) && obj.receiveInteraction(initiator)) {
	            return true; // Interaction successful
	        }
	    }
	    return false; // No valid interaction
	}
	
	public boolean interactWithPosition(GameItem initiator, Position pos) {
	    for (GameObject obj : gameObjects) {
	        if (obj.isInPosition(pos)) {
	            return obj.receiveInteraction(initiator); // Perform the interaction
	        }
	    }
	    return false; // No object to interact with
	}

	public boolean receiveInteractionAtPosition(Position pos, GameItem initiator) {
	    for (GameObject obj : gameObjects) {
	        if (obj.isInPosition(pos)) {
	            return obj.receiveInteraction(initiator);
	        }
	    }
	    return false; // No interaction occurred
	}
	
	public boolean digAtPosition(GameItem initiator, Position targetPos) {
	    for (GameObject obj : gameObjects) {
	        if (obj.isInPosition(targetPos)) {
	            return obj.receiveInteraction(initiator); // Perform the interaction
	        }
	    }
	    return false; // No object at the position to interact with
	}



}
	
	