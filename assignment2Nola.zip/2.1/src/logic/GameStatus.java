package logic;

public interface GameStatus {
	// Represents the view's view
	int getCycle();
	int numLemmingsInBoard();
	int numLemmingsDead();
	int numLemmingsExit();
	int numLemmingsToWin();
	String positionToString(int col, int row);
	int getLevel();
	
	// TODO add all methods that return information about the state of the game
	// Needed to display the current state

}
