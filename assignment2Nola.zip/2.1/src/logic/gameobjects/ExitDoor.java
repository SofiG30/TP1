package logic.gameobjects;

import logic.*;
import view.*;
public class ExitDoor extends GameObject {
	
	private Position positionDoor;
	private Game game;

	public ExitDoor(Game game, Position pos) {
		super(game, pos,false,true,false);
		this.positionDoor = pos;
		// TODO Auto-generated constructor stub
	}

		
	public Position getPosition() {
		return super.getPosition();
	}
	
	@Override
	public String toString() {
		return Messages.EXIT_DOOR;
	}
	
	public void update() {}
	
	@Override
	public boolean isExit() {
		return true;
	}
	
	@Override
	public boolean receiveInteraction(GameItem other) {
	    return other.interactWith(this);
	}

	@Override
	public boolean interactWith(Lemming lemming) {
	    if (lemming.isAlive() && !lemming.hasExited()) {
	        lemming.setExited(true);
	        return true;
	    }
	    return false;
	}

	@Override
	public boolean interactWith(Wall wall) {
	    return false; 
	}

	@Override
	public boolean interactWith(ExitDoor door) {
	    return false; 
	}

}


