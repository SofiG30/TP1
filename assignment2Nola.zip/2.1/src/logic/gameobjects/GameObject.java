package logic.gameobjects;

import logic.lemmingRoles.*;
import logic.*;
import logic.Position;
//Attributes and non-abstract methods should be placed in the highest class possible
public abstract class GameObject implements GameItem{
	// Contains all the attributes and methods that are common to all the concrete game objects
	// Where appropriate -> Concrete game objects can overwrite inherited methods to implement its own behavior

	private Game game;
	private Position pos;
	private boolean exited = false;
	private boolean solid;
	private boolean inanimate;
	private boolean alive;
	
	// Constructor 
	public GameObject(Game game, Position pos, boolean solid, boolean inanimate, boolean alive) {
		this.game = game;
		this.inanimate =  inanimate;
		this.pos = pos;
		this.solid = solid;
		this.alive = alive;
	}
	
	public Position getPosition() {
		return pos;
	}
	
	public boolean isInanimate() {
		return inanimate;
	}
	
	public boolean hasExited() {
		return exited;
	}
	
	public boolean isSolid() {
		return solid;
	}
	
	public boolean isAlive() {
		return alive;
	}
	
	public void setPosition(Position pos) {
		this.pos = pos;
	}
	
	public void setAlive(boolean alive) {
		this.alive = alive;
	}
	
	public abstract String toString();
		
	public void update() {
		
	}
	
	public boolean isInAir() {
		return game.isInAir(pos);
	}
	
	public boolean isExit() {
		return false;
	}
	
	public boolean isPositionSolid(Position pos) {
	    return game.isPositionSolid(pos);
	}

	public boolean hasLemmingArrived(Position pos) {
        return game.lemmingArrived(pos);
    }
	
	@Override
	public boolean isInPosition(Position pos) {
		return this.getPosition().equals(pos);
	}
	
	public boolean setRole(LemmingRole role) {
		//GameObjects can't have roles
		//default implementation
		return false;
	}
	
	@Override
	public boolean interactWith(Wall wall) {
		return false;
	}
	
	@Override
	public boolean interactWith(ExitDoor door) {
		return false;
	}
	
	

}



























