package logic.gameobjects;

import logic.Game;
import logic.GameItem;
import logic.Position;
import view.Messages;

public class MetalWall extends GameObject{

	private Position positionWall;
	private Game game;
	
	public MetalWall(Game game, Position pos) {
		super(game, pos,true,true,false);
		this.positionWall = pos;		
	}
	
	@Override
	public boolean interactWith(Lemming lemmy){
		//can't dig
		return false;
	}
	
	@Override
	public boolean canBeDug() {
		//can't dig metal wall
		return false;
	}
	
	
	@Override
	public boolean interactWith(MetalWall wall) {
		return false;
	}
	
	@Override
	public boolean receiveInteraction(GameItem other) {
	    return other.interactWith(this);
	}
	
	@Override
	public boolean interactWith(Wall wall) {
	    return false; 
	}

	@Override
	public boolean interactWith(ExitDoor door) {
	    return false;
	}
	@Override
	public String toString() {
		return Messages.WALL;
	}
}
