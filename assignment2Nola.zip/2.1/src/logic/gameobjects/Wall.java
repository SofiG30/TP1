package logic.gameobjects;
import logic.*;
import view.*;

public class Wall extends GameObject{
	
	private Position positionWall;
	private Game game;
	//true if wall is diggable
	
	// Constructor
	public Wall(Game game, Position pos) {
		super(game, pos,true,true,false);
		this.positionWall = pos;
		// TODO Auto-generated constructor stub
		
	}

	
	// Getter method
	public Position getPosition() {
		return super.getPosition();
	}
	
	@Override
	public boolean isExit() {
		return false;
	}
	
	@Override
	public String toString() {
		return Messages.WALL;
	}
		
	public void update() {}
	
	@Override
	public boolean receiveInteraction(GameItem other) {
	    return other.interactWith(this);
	}

	@Override
	public boolean canBeDug() {
		return true;
	}
	
	@Override
	public boolean interactWith(Lemming lemming) {
		//regular wall is diggable, remove it and lemming moves
		//to that spot
	    setAlive(false);
	    lemming.setPosition(getPosition()); 
	    return true;
	    
	}

	@Override
	public boolean interactWith(Wall wall) {
	    return false; 
	}

	@Override
	public boolean interactWith(ExitDoor door) {
	    return false;
	}

}
