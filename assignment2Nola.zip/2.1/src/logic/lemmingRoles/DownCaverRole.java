package logic.lemmingRoles;

import logic.*;
import logic.gameobjects.*;
import view.*;

public class DownCaverRole implements LemmingRole {

    @Override
    public void start(Lemming lemming) {
        // no initialization needed
    }

    @Override
    public void advance(Lemming lemming) {
        Position currentPos = lemming.getPosition();
        Position belowPos = new Position(currentPos.get_col(), currentPos.get_row() + 1);
        
        // Attempt to dig up  the object below
        boolean dug = lemming.digBelow(belowPos);
        
        // If you can't dig, go back to walker role (default behav)
        if (!dug) {
            lemming.disableRole();
        }
    }

    @Override
    public String getIcon(Lemming lemming) {
        return Messages.LEMMING_DOWN_CAVER;
    }

    @Override
    public boolean receiveInteraction(GameItem other, Lemming lemming) {
        return other.interactWith(lemming);
    }

    @Override
    public boolean interactWith(Lemming one, Lemming two) {
        // No interaction between lemmings
    	return false; 
    }

    @Override
    public boolean interactWith(Wall wall, Lemming lemming) {
        return true;
    }
    

    @Override
    public boolean interactWith(ExitDoor door, Lemming lemming) {
        return false; // ExitDoor has no effect on the DownCaverRole
    }

    @Override
    public boolean isStateless() {
        return false; // DownCaverRole is stateful
    }

    @Override
    public LemmingRole newInstance() {
        return new DownCaverRole();
    }

    @Override
    public boolean matches(String input) {
        return input.equalsIgnoreCase("DownCaver") || input.equalsIgnoreCase("DC");
    }
}
