package logic.lemmingRoles;

import logic.*;
import logic.gameobjects.*;

public interface LemmingRole {
	
	//action when assigned a roke
	void start(Lemming lemming);
	//action taken each cycle
	void advance(Lemming lemming);
	//icon to display role
	String getIcon(Lemming lemming);
	
	//interaction methods
	boolean receiveInteraction(GameItem other, Lemming lemmy);
	
	boolean interactWith(Lemming one, Lemming two);
	boolean interactWith(Wall wall, Lemming lemmy);
	boolean interactWith(ExitDoor door, Lemming lemmy);
	
	//additional methods
	boolean isStateless();
	LemmingRole newInstance();
	boolean matches(String input);
}
