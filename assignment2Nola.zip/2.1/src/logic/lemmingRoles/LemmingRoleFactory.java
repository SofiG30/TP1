package logic.lemmingRoles;

import java.util.Arrays;
import java.util.List;

public class LemmingRoleFactory {
	
	private static final List<LemmingRole> AVAILABLE_ROLES = Arrays.asList(
		new WalkerRole(),
		new ParachuterRole()
	);
	
	public static LemmingRole parse(String input) {
		for(LemmingRole role : AVAILABLE_ROLES) {
			if(role.matches(input)) {
				return role.isStateless() ? role : role.newInstance();
			}
		}
		throw new IllegalArgumentException("Unknown role: " +input);
	}

}
