package logic.lemmingRoles;

import logic.*;
import logic.gameobjects.*;

public class ParachuterRole implements LemmingRole{

	@Override
	public void start(Lemming lemmy) {
		//reset force fall when assigned
		lemmy.setForceFall(0);
	}
	
	@Override
	public void advance(Lemming lemmy) {
		Position curr = lemmy.getPosition();
		if(lemmy.isInAir()) {
			//fall w/o dying
			lemmy.setPosition(new Position(curr.get_col(), curr.get_row()));
		}
		else {
			//go back to walker role if landed
			lemmy.disableRole();
		}
	}
	
	@Override 
	public boolean isStateless() {
		//false for ParachuterRole
		return false;
	}
	
	@Override
	public LemmingRole newInstance() {
		return new ParachuterRole();
	}
	
	@Override
	public boolean matches(String input) {
        return input.equalsIgnoreCase("Parachuter") || input.equalsIgnoreCase("P");
	}
	
	@Override
	public String getIcon(Lemming lemmy) {
		return "🪂";
	}
	
	@Override
	public boolean receiveInteraction(GameItem other, Lemming lemmy) {
		//default behavior is no interactions
		return false;
	}
	
	//all interactions are false bc parachute role doesn't interact
	@Override
	public boolean interactWith(Lemming one, Lemming two) {
		return false;
	}
	
	@Override
	public boolean interactWith(Wall wall, Lemming lemmy) {
		return false;
	}
	
	@Override
	public boolean interactWith(ExitDoor door, Lemming lemmy) {
		return false;
	}
}
