package logic.lemmingRoles;
import logic.*;
import logic.gameobjects.*;
import view.*;
public class WalkerRole implements LemmingRole{
	
	@Override
	public void start(Lemming lemmy) {
		
	}
	
	@Override
	public void advance(Lemming lemmy) {
		lemmy.walkFall();
	}
	 
	@Override
	public String getIcon(Lemming lemmy) {
		
		if (!lemmy.isAlive() || lemmy.hasExited()) {
			return "";
		}
		
		if (lemmy.getDirection() == Direction.RIGHT) {
			return Messages.LEMMING_RIGHT;
		}
		else {
			return Messages.LEMMING_LEFT;
		}
		
	}
	
	@Override
	public boolean isStateless() {
		return true;
	}
	
	@Override public LemmingRole newInstance() {
		return this;
	}
	
	@Override
	public boolean matches(String input) {
		return input.equalsIgnoreCase("Walker") || input.equalsIgnoreCase("W");
	}
	
	@Override
	public boolean interactWith(Lemming one, Lemming two) {
		return false;
	}
	
	@Override 
	public boolean interactWith(Wall wally, Lemming lemmy) {
		//check if wall is blocking movement
		if(lemmy.isPositionSolid(wally.getPosition())) {
			//change direction if there's a wall
	        lemmy.setDirection(lemmy.getDirection() == Direction.RIGHT ? Direction.LEFT : Direction.RIGHT);
	        return true;
		}
		//no interaction
		return false;
	}
	
	@Override
	public boolean interactWith(ExitDoor doory, Lemming lemmy) {
		//check if at exit door
		if(lemmy.getPosition().equals(doory.getPosition())) {
			lemmy.setExited(true);
			return true;
		}
		//no interaction
		return false;
	}
	
	@Override
	public boolean receiveInteraction(GameItem other, Lemming lemming) {
	    return other.interactWith(lemming);
	}

}
