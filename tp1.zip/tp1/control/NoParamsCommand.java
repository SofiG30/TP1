package tp1.control;

import tp1.logic.Game;
import tp1.logic.GameModel;
import tp1.view.GameView;

public abstract class NoParamsCommand extends Command {
	// Base class of any command class representing a command with no parameters

	public NoParamsCommand(String name, String shortcut, String details, String help) {
		super(name, shortcut, details, help);
		// TODO Auto-generated constructor stub
	}

	protected boolean matchCommand(String command) {
		// Checks if the first word of the text corresponds to the command name -> parse method : TO DO
		return command.equalsIgnoreCase(super.getName()) || command.equalsIgnoreCase(super.getShortcut());
	}
	
	public Command parse(String[]command) {
		// Checks if the text introduced by the user corresponds to a use of the command -> Check validity of the parameter values : TO DO
		if (command.length == 1 && matchCommand(command[0])) {
			return this;
		}
		return null;	
	}
	
	public void execute(GameModel game, GameView view) {
	
	}
			
}
