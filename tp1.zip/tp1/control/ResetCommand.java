package tp1.control;

import tp1.logic.Game;
import tp1.logic.GameModel;
import tp1.view.GameView;
import tp1.view.Messages;

public class ResetCommand extends Command {

	private static final String NAME = Messages.COMMAND_RESET_NAME;
	private static final String SHORTCUT = Messages.COMMAND_RESET_SHORTCUT;
	private static final String DETAILS = Messages.COMMAND_RESET_DETAILS;
	private static final String HELP = Messages.COMMAND_RESET_HELP;
	private int level = -1;
	
	public ResetCommand() {
		super(NAME, SHORTCUT, DETAILS, HELP);
		// TODO Auto-generated constructor stub
	}


	@Override
	public void execute(GameModel game, GameView view) {
		if (level == -1) {
			level = ((Game)game).getLevel();
		}
		if (0<= level && level <= 4) {
			game.reset(level);
			view.showGame();		
		} else {
			view.showError(Messages.NOT_VALID_LEVEL);
		}
		
	}


	@Override
	public Command parse(String[] command) {
		// TODO Auto-generated method stub
		if (command.length == 1 && (command[0].equalsIgnoreCase(NAME) || command[0].equalsIgnoreCase(SHORTCUT))) {
			return this;
		} else if (command.length == 2){
			// The command has a parameter
			this.level  = Integer.parseInt(command[1]);
				return this;
		}
		return null;
	}

}
