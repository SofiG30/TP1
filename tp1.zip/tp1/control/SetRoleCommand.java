package tp1.control;

import tp1.logic.GameModel;
import tp1.logic.lemmingRoles.LemmingRoleFactory;
import tp1.view.GameView;
import tp1.view.Messages;

//3 args : role to be applied and 2 coordinates

public class SetRoleCommand extends Command {
	
	private static final String NAME = Messages.COMMAND_SET_ROLE_NAME;
	private static final String SHORTCUT = Messages.COMMAND_SET_ROLE_SHORTCUT;
	private static final String DETAILS = Messages.COMMAND_SET_ROLE_DETAILS;
	private static final String HELP = Messages.COMMAND_SET_ROLE_HELP;
	
	private String role;
	private int col;
	private String row;

	public SetRoleCommand() {
		super(NAME, SHORTCUT, DETAILS, HELP);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public Command parse(String[] command) {
		if (command.length < 4) {
			System.out.println(Messages.COMMAND_PARAMETERS_MISSING);
		} else if (command.length > 4) {
			System.out.println(Messages.COMMAND_INCORRECT_PARAMETER_NUMBER);
		} else if (command[0].equalsIgnoreCase(NAME) || command[0].equalsIgnoreCase(SHORTCUT)) {
			this.role = command[1];
			this.row = command[2].toUpperCase();//pour que ca accept les lowercase aussi
			this.col = Integer.parseInt(command[3]) - 1;
			return this;
		}
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void execute(GameModel game, GameView view) {
		// TODO Auto-generated method stub
		game.setRole(role,col,row);
		game.update();
		view.showGame();
		
	}

	
	@Override
	public String helpText() {
		return super.helpText() + LemmingRoleFactory.commandHelp();
	}
}
