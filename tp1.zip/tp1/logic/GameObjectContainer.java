package tp1.logic;
import java.util.ArrayList;
import java.util.List;

import tp1.logic.gameobjects.ExitDoor;
import tp1.logic.gameobjects.GameItem;
import tp1.logic.gameobjects.GameObject;
import tp1.logic.gameobjects.Lemming;
import tp1.logic.gameobjects.Wall;
import tp1.logic.lemmingRoles.LemmingRole;
import tp1.logic.lemmingRoles.LemmingRoleFactory;
import tp1.view.Messages;

public class GameObjectContainer {
	//TODO fill your code
	private List<GameObject> gameObjects;
	private int deadLemmings = 0;
	private int exitedLemmings = 0;
	private int nbLemmings = 0;
	
	// Constructor 
	public GameObjectContainer() { 
		gameObjects = new ArrayList<>();
	}
	
	public int getNbLemmings() {
		return nbLemmings;
	}
	
	// method that takes a game object and adds it to the list
	public void add(GameObject object) {
		gameObjects.add(object);
		if (object !=null  && object.isAlive()) {
			nbLemmings ++;
		}
	}
	
	// methods for the display of objects
	public String drawBoard(int col, int row) {
		StringBuilder multiplelem = new StringBuilder();
		for (GameObject object : gameObjects) {
			if (object!=null && object.isInPosition(new Position(col,row))) {
				multiplelem.append(object.toString());
			}
		}
		return multiplelem.toString();
	}
	
	
	public boolean spaceOccupied(int col, int row) {
		for (GameObject object : gameObjects) {
			if (object != null && !object.isAlive() && !object.isExit()) { 
				if (object.isInPosition(new Position(col,row))) {
					return true;
				}
			}
		}
		return false;
	}
	
	
	public boolean InAir(Position pos) {
		return !spaceOccupied(pos.get_col(), pos.get_row() +1);
	}
	
	
	
	public int nbDeadLemmings() {
		deadLemmings = 0;
		for (GameObject object : gameObjects) {
			if (object != null && !object.isAlive() && !object.isSolid() && !object.isExit()) {
					deadLemmings++;								
			}
		}
		return deadLemmings;
	}
	
	
	public Position DoorPos() {
		for (GameObject object: gameObjects) {
			if (object!= null && object.isExit()) {
				return object.getPosition();
			}
		}
		return null;
	}
	
	public boolean lemmingArrived(Position pos) {
		Position doorPos = DoorPos();
		if (doorPos.get_col() == pos.get_col() && doorPos.get_row() == pos.get_row()) {
			return true;
		}
		return false;
	}
	
	
	public int nbExitLemmings() {
		exitedLemmings = 0;
		for (GameObject object : gameObjects) {
			if (object != null) {
				Position posObject = object.getPosition();
				if (lemmingArrived(posObject) && object.isAlive()) {
					//System.out.println("Increase exited lemmings counter\n");
					exitedLemmings++;
				}
			}
		}
		return exitedLemmings;
	}
	
	
	
	public boolean isLemmingPos(int col, int row) {
		for (GameObject object: gameObjects) {
			if (object != null) {
				if (object.isAlive() && object.isInPosition(new Position(col,row))) {
					return true;
				}
			}
		}
		return false;
	}
	
	
	// Not sure if is the correct implementation
	public void setRole(String role,int col, String row) {
		int i_row = row.charAt(0) - 'A';
		if (!isLemmingPos(col,i_row)) {
			System.out.println(Messages.INCORRECT_POS_SET_ROLE);
		} else {
			if (LemmingRoleFactory.parse(role) == null) {
				System.out.println(Messages.UNKNOWN_ROLE);
			} else {
				boolean assigned = false;
				for (GameObject object: gameObjects) {
					LemmingRole newRole = LemmingRoleFactory.parse(role);
					if (object.isInPosition(new Position(object.getPosition().get_col(), i_row))) {
						object.setRole(newRole);
						assigned = true;
						break;
					}
				}
			}
		}
		
	}
	
	
	public void update() {
		for (GameObject object : gameObjects) {
			if (object != null) {
			object.update();
			}
		}
	}
	
	
	// Method that carries out all the interactions of an object
	public boolean receiveInteractionsFrom(GameItem obj) {
		for( GameObject object : gameObjects) {
			if (object.receiveInteraction(obj)) {
				return true;
			}
		}
		return false;
		
	}

	public GameItem ItemAt(int col, int row) {
		for (GameObject object : gameObjects) {
			if (object != null) {
				Position p = new Position(col,row);
				if (object.isInPosition(p)) {
					return object;
				}
			}
		}
		return null;
	}
	
	public void removeItem(Position pos) {
	    for (int i = 0; i < gameObjects.size(); i++) {
	        GameObject object = gameObjects.get(i);
	        if (object.isInPosition(pos)) {
	            gameObjects.set(i, null);  // Set the object at index i to null
	            break;  // Exit the loop after finding and setting the first matching object
	        }
	    }
	}

}


	
	