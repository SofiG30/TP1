package tp1.logic;

import tp1.logic.gameobjects.GameItem;

public interface GameWorld {
	// Represents the model's view
	
	boolean isInAir(Position pos);
	boolean lemmingArrived(Position pos);
	boolean receiveInteractionsFrom(GameItem obj);
	
	// TODO invoke methods of the game that concern interactions between game objects
	

}
