package tp1.logic.gameobjects;

import tp1.logic.Game;
import tp1.logic.Position;
import tp1.logic.lemmingRoles.LemmingRole;
import tp1.view.Messages;
public class ExitDoor extends GameObject {
	

	public ExitDoor(Game game, Position pos) {
		super(game, pos,false,false,true);
		// TODO Auto-generated constructor stub
	}

		
	@Override
	public String toString() {
		return Messages.EXIT_DOOR;
	}
	
	public void update() {}
	

	@Override
	public boolean receiveInteraction(GameItem other) {
		// TODO Auto-generated method stub
		return other.interactWith(this);
	}


	@Override
	public boolean interactWith(Lemming lemming) {
		// TODO Auto-generated method stub
		return lemming.isInPosition(this.getPosition());
	}


	@Override
	public boolean interactWith(Wall wall) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean interactWith(ExitDoor door) {
		// TODO Auto-generated method stub
		return false;
	}
}


