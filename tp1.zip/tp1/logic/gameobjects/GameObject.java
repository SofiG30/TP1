package tp1.logic.gameobjects;

import tp1.logic.Game;
import tp1.logic.Position;
import tp1.logic.lemmingRoles.LemmingRole;
//Attributes and non-abstract methods should be placed in the highest class possible
public abstract class GameObject implements GameItem {
	// Contains all the attributes and methods that are common to all the concrete game objects
	// Where appropriate -> Concrete game objects can overwrite inherited methods to implement its own behavior

	
	// TODO i
	private Game game;
	private Position pos;
	private boolean solid;
	private boolean alive;
	private boolean exit;
	
	
	// Constructor 
	public GameObject(Game game, Position pos, boolean solid, boolean alive, boolean exit) {
		this.game = game;
		this.pos = pos;
		this.solid = solid;
		this.alive = alive;
		this.exit = exit;
	}
	
	public Position getPosition() {
		return pos;
	}
		
	public Game getGame() {
		return game;
	}
	public boolean isSolid() {
		return solid;
	}
	
	public boolean isAlive() {
		return alive;
	}
	
	public boolean isExit() {
		return exit;
	}
	
	public void setPosition(Position pos) {
		this.pos = pos;
	}
	
	public boolean isInPosition(Position pos) {
		if (this.pos.get_col() == pos.get_col() && this.pos.get_row() == pos.get_row()) {
			return true;
		}
		return false;
	}
	
	public void setAlive(boolean alive) {
		this.alive = alive;
		
	}
	
	public void setExit(boolean exit) {
		this.exit = exit;
	}
	
	public abstract String toString();
		
	public void update() {
		
	}
	
	public boolean setRole(LemmingRole role) {
		return false;
	}

}



























