package tp1.logic.gameobjects;
import tp1.logic.Direction;
import tp1.logic.Position;
import tp1.logic.lemmingRoles.LemmingRole;
import tp1.logic.lemmingRoles.WalkerRole;
import tp1.view.Messages;
import tp1.logic.Game;

public class Lemming extends GameObject{
	private int forceFall;
	private Game game;
	private LemmingRole role;
	private Direction direction;
	
	// Constructor for an object of class lemming
	public Lemming(Game game, Position pos, Direction direction, LemmingRole role) {
		super(game, pos,false,true,false);
		this.game = game;
		this.forceFall = 0; // Init value
		this.role = role;
		this.direction = direction;  
	}
	
	// getters		
	public int getForceFall() {
		return forceFall;
	}
	
	public void setForceFall(int val) {
		this.forceFall = val;
	}
	
	public LemmingRole getRole() {
		return role;
	}
	
	
	public Direction getDirection() {
		return direction;
	}
	
	public Game getGame() {
		return game;
	}
	
	
	@Override
	public String toString() {
		return role.getIcon(this);
	}
	
	
	// move method 
	public void fall() {

		int x  = getPosition().get_col();
		int y = getPosition().get_row();
		
		forceFall++;
		setPosition(new Position(x, y+1));	
	}
	
	public void walk() {
		int x  = getPosition().get_col();
		int y = getPosition().get_row();
		
		if (direction == Direction.LEFT) {
			if ( x != 0 && !game.getContainer().spaceOccupied(x-1, y)) {
				setPosition(new Position(x-1,y));
			} else 
				direction = Direction.RIGHT;
		} else if (direction == Direction.RIGHT) {
			if ( x != (Game.DIM_X -1) && !game.getContainer().spaceOccupied(x+1, y)) {
				setPosition(new Position(x+1, y));
			} else
				direction = Direction.LEFT;
		}
	}
		
	public boolean exitBoard() {
		int y = getPosition().get_row();
		if (y+1 >= Game.DIM_Y) {
			return true;
		}
		return false;
	}
	
	public boolean reachedDoor() {
		
		return game.lemmingArrived(this.getPosition());
	}
	
	
	public void walkFall() {
		
		// Check if the lemming has reached the exit door
		if (reachedDoor()) {
			setExit(true);
			//System.out.println("The lemming has reached the door\n");
			return;
		}
		
		// Check if the lemming exits the board
		if (exitBoard()) {
			setAlive(false);
			return;
		}
		
		if (isExit()) {
			return;
		}
	
		// Check if there's no wall below the lemming
		if (game.getContainer().InAir(getPosition())) {
			fall();
			return;
		} else {
			// The lemming hit the ground
			if (forceFall >= 3) {
				setAlive(false);
				return;
			} else {
				setForceFall(0);
			}	
		}
		walk();
		
	}

	@Override
	public boolean setRole(LemmingRole role) {
		this.role = role;
		return true;
	}
	
	
	public void disableRole() {
		role = new WalkerRole();
	}
	
	@Override
	public void update() {
		// Check first that the lemming is alive 
		if (!isAlive() || isExit()) return;
		// Call the advance of the WalkerRole
		role.advance(this);
		}

	@Override
	public boolean receiveInteraction(GameItem other) {
		return other.interactWith(this);
		// TODO Auto-generated method stub
	}


	@Override
	// Needs to check the role first to determine the interaction
	public boolean interactWith(Wall wall) {
		// TODO Auto-generated method stub
		return getRole().interactWith(wall,this);
	}


	@Override
	public boolean interactWith(Lemming lemming) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean interactWith(ExitDoor door) {
		// TODO Auto-generated method stub
		return door.isInPosition(this.getPosition());
	}
	
	}

