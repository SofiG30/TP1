package tp1.logic.gameobjects;

import tp1.logic.Game;
import tp1.logic.Position;
import tp1.view.Messages;

public class MetalWall extends Wall{

	public MetalWall(Game game, Position pos) {
		super(game, pos, false);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return Messages.METAL_WALL;
	}
	
	@Override
	public boolean interactWith(Lemming lemming) {
		// TODO Auto-generated method stub
		return false;
	}

}
