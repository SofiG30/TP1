package tp1.logic.gameobjects;
import tp1.logic.Game;
import tp1.logic.Position;
import tp1.logic.lemmingRoles.LemmingRole;
import tp1.view.Messages;

public class Wall extends GameObject{
	
	private boolean isSoft;
	
	// Constructor
	public Wall(Game game, Position pos, boolean soft) {
		super(game, pos,true,false,false);
		this.isSoft = soft;
		
		// TODO Auto-generated constructor stub
	}
	
	public boolean isSoft() {
		return this.isSoft;
	}

	
	@Override
	public String toString() {
		return Messages.WALL;
	}
		
	public void update() {}
	
	
	@Override
	public boolean receiveInteraction(GameItem other) {
		// TODO Auto-generated method stub
		return other.interactWith(this);
	}


	@Override
	// TODO check role of the lemming
	public boolean interactWith(Lemming lemming) {
		return lemming.getRole().interactWith(this, lemming);
	}


	@Override
	public boolean interactWith(Wall wall) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean interactWith(ExitDoor door) {
		// TODO Auto-generated method stub
		return false;
	}
}
