package tp1.logic.lemmingRoles;

import tp1.logic.Position;
import tp1.logic.gameobjects.GameItem;
import tp1.logic.gameobjects.Lemming;
import tp1.logic.gameobjects.Wall;
import tp1.view.Messages;

public class DownCaverRole extends Roles{
	
	private static final String SHORTCUT = "DownCaver";
	private static final String NAME = "DC";
	private static final String DETAILS = "[D]own [C]aver";
	private static final String HELP = "Lemming caves downwards";

	public DownCaverRole() {
		super(NAME, SHORTCUT, DETAILS, HELP);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void advance(Lemming lemming) {
		// TODO Auto-generated method stub
		if (!lemming.isAlive() || lemming.isExit()) {
			return;
		}
		
		if (lemming.reachedDoor()) {
			lemming.setExit(true);
			return;
		}
		
		// Check the position below the lemming
		Position lemmingPos = lemming.getPosition();
		Position belowPos = new Position(lemmingPos.get_col(), lemmingPos.get_row() +1);
		
		// Check if there is a soft wall below 
		GameItem itemBelow = lemming.getGame().getContainer().ItemAt(belowPos.get_col(), belowPos.get_row());
		
		if (itemBelow == null) {
			System.out.println("nothing below\n");
			lemming.disableRole();
			return;
		}
	
		if (lemming.getGame().receiveInteractionsFrom(itemBelow)) {
			System.out.println("wall below lemming");
			lemming.getGame().getContainer().removeItem(belowPos);
			lemming.setPosition(belowPos);
		} else {
			lemming.disableRole();
		}
	
	}
	

	@Override
	public String getIcon(Lemming lemming) {
		// TODO Auto-generated method stub
		return Messages.LEMMING_DOWN_CAVER;
	}

	@Override
	public LemmingRole createInstance() {
		// TODO Auto-generated method stub
		return new DownCaverRole();
	}

	@Override
	public boolean interactWith(Wall wall, Lemming lemming) {
		if (wall.isSoft()) {
			System.out.println("Wall is soft\n");
			return true;
		}
		return false;
	}
}

