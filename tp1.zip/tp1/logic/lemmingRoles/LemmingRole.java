package tp1.logic.lemmingRoles;

import tp1.logic.gameobjects.ExitDoor;
import tp1.logic.gameobjects.GameItem;
import tp1.logic.gameobjects.Lemming;
import tp1.logic.gameobjects.Wall;

public interface LemmingRole {
	public void start(Lemming lemming);
	public void advance(Lemming lemming);
	public String getIcon(Lemming lemming);
	public LemmingRole parse(String input);
	public LemmingRole createInstance();
	public String helpText();
	public boolean receiveInteraction(GameItem other, Lemming lemming);
	public boolean interactWith(Lemming Receiver, Lemming emming);
	public boolean interactWith(Wall wall, Lemming lemming);
	public boolean interactWith(ExitDoor door, Lemming lemming);
}
