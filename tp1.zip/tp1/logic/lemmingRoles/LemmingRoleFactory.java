package tp1.logic.lemmingRoles;

import java.util.Arrays;
import java.util.List;

import tp1.logic.gameobjects.Lemming;

public class LemmingRoleFactory {
	
	private static final List<LemmingRole> LEMMING_ROLES = Arrays.asList 
			(
					new DownCaverRole(),
					new WalkerRole(),
					new ParachuterRole()
			);

	public static LemmingRole parse(String input) {
		for (LemmingRole lemmy : LEMMING_ROLES ) {
			if (lemmy.parse(input) != null) {
				return lemmy.createInstance();
			}
		}
		return null;
		
	}
	
	public static String commandHelp() {
		String help = "\n";
		for (LemmingRole lemmy : LEMMING_ROLES) {
			if (lemmy.helpText() != null) {
				help += lemmy.helpText() + "\n";
			}
		}
		return help;
	}
}
