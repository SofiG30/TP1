package tp1.logic.lemmingRoles;

import tp1.logic.gameobjects.Lemming;
import tp1.view.Messages;

public class ParachuterRole extends Roles{

	private static final String SHORTCUT = "Parachuter";
	private static final String NAME = "P";
	private static final String DETAILS = "[P]arachuter";
	private static final String HELP = "Lemming that falls with a parachute";
	
	public ParachuterRole() {
		super(NAME, SHORTCUT, DETAILS, HELP);
		// TODO Auto-generated constructor stub
	}

	@Override 
	public void start(Lemming lemming) {
		if (lemming.getGame().getContainer().InAir(lemming.getPosition())) {
			lemming.setForceFall(0);
		}
	}
	
	public void advance(Lemming lemming) {
		// TODO Auto-generated method stub
		// Check if the lemming has reached the exitDoor
		if (lemming.isExit() || !lemming.isAlive()) {
			return;
		}
		
		if (lemming.reachedDoor()) {
			lemming.setExit(true);
			return;
		}
		
		// Check if the lemming is in the air 
		if (lemming.getGame().getContainer().InAir(lemming.getPosition())) {
			lemming.fall();
			return;
		} else {
			// lemming has hit the ground
			lemming.setForceFall(0);
			lemming.disableRole();
			return;
		}
	}

	
	public String getIcon(Lemming lemming) {
		// TODO Auto-generated method stub
		if (!lemming.isAlive() || lemming.isExit()) {
			return null;
		}
		return Messages.PARACHUTE;
	}
	
	
	
	public LemmingRole createInstance() {
		return new ParachuterRole();
	}
	
	
}
