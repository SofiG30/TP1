package tp1.logic.lemmingRoles;
import tp1.logic.Direction;
import tp1.logic.gameobjects.Lemming;
import tp1.view.Messages;
public class WalkerRole extends Roles {
	
	
	private static final String NAME = "Walker";
	private static final String SHORTCUT = "W";
	private static final String DETAILS = "[W]alker";
	private static final String HELP = "Lemming that walks";
	
	
	public WalkerRole() {
		super(NAME, SHORTCUT, DETAILS, HELP);
		// TODO Auto-generated constructor stub
	}


	
	public void advance(Lemming lemmy) {
		lemmy.walkFall();
	}
	 
	public String getIcon(Lemming lemmy) {
		
		if (!lemmy.isAlive() || lemmy.isExit()) {
			return "";
		}
		
		if (lemmy.getDirection() == Direction.RIGHT) {
			return Messages.LEMMING_RIGHT;
		} else  {// direction left 
			return Messages.LEMMING_LEFT;
		}
		
	}


	public LemmingRole createInstance() {
		return new WalkerRole();
	}

	
}
